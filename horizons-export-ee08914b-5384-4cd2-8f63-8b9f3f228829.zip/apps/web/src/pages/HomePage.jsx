import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Phone, CheckCircle, Home, Hammer, Ruler, Layout, HardHat, Construction } from 'lucide-react';

const HomePage = () => {
  const services = [
    {
      title: 'Home Additions',
      description: 'Expand your living space with seamless additions. We handle everything from foundation to finish, ensuring your new space matches your home perfectly.',
      icon: Home,
      link: '/services'
    },
    {
      title: 'Kitchen Remodeling',
      description: 'Update the heart of your home. We solve layout issues and install high-quality cabinets and fixtures for a kitchen that works for your family.',
      icon: Layout,
      link: '/services'
    },
    {
      title: 'Bathroom Remodeling',
      description: 'Transform outdated bathrooms into modern, functional spaces. We focus on waterproofing, efficient fixtures, and durable tile installation.',
      icon: Hammer,
      link: '/services'
    },
    {
      title: 'Basement Finishing',
      description: 'Turn your unfinished basement into valuable living square footage. Perfect for home offices, playrooms, or entertainment areas.',
      icon: Ruler,
      link: '/services'
    },
    {
      title: 'Full Home Renovations',
      description: 'Complete interior and exterior makeovers. We manage the entire project timeline to revitalize your property from top to bottom.',
      icon: Construction,
      link: '/services'
    },
    {
      title: 'Structural Remodeling',
      description: 'Safe and professional structural changes. We specialize in removing load-bearing walls and reconfiguring layouts securely.',
      icon: HardHat,
      link: '/services'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Linart Construction Inc. - Residential Additions & Remodeling in NJ</title>
        <meta name="description" content="Family-owned since 2004. Linart Construction specializes in residential additions and remodeling across New Jersey. 80+ years of combined experience." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://horizons-cdn.hostinger.com/ee08914b-5384-4cd2-8f63-8b9f3f228829/remotemediafile_6619721_0_2022_05_05_12_30_52-sS9RR.jpeg"
            alt="New Jersey Residential Home"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-charcoal/80"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-warm-white mb-6 leading-tight">
              Residential Additions & Remodeling<br />
              <span className="text-slate-200">Across New Jersey</span>
            </h1>
            <p className="text-xl sm:text-2xl text-slate-300 mb-10 max-w-3xl mx-auto">
              Family-owned since 2004. 80+ years of combined experience.<br />
              Quality craftsmanship you can trust.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link
                to="/contact"
                className="bg-deep-blue text-warm-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-opacity-90 transition-all duration-200 shadow-lg hover:shadow-xl w-full sm:w-auto"
              >
                Request a Free Estimate
              </Link>
              <a
                href="tel:6092097810"
                className="bg-white text-charcoal px-8 py-4 rounded-lg text-lg font-semibold hover:bg-slate-100 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center justify-center gap-2 w-full sm:w-auto"
              >
                <Phone size={20} />
                Call Now: 609-209-7810
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Why Linart Construction Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal mb-6">
              Built on Experience. Trusted by Homeowners.
            </h2>
            <div className="flex flex-col md:flex-row justify-center items-center gap-8 mb-10 text-left md:text-center">
              <div className="flex items-center gap-3">
                <CheckCircle className="text-deep-blue flex-shrink-0" size={24} />
                <span className="text-lg text-slate-700">Family-Owned & Operated Since 2004</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="text-deep-blue flex-shrink-0" size={24} />
                <span className="text-lg text-slate-700">80+ Years Combined Experience</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="text-deep-blue flex-shrink-0" size={24} />
                <span className="text-lg text-slate-700">Serving All of New Jersey</span>
              </div>
            </div>
            <Link
              to="/about"
              className="inline-flex items-center gap-2 text-deep-blue font-bold text-lg hover:underline decoration-2 underline-offset-4"
            >
              Learn More About Us <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Services Overview Grid */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal mb-4">Our Core Services</h2>
            <p className="text-slate-600 max-w-2xl mx-auto text-lg">
              We specialize in major residential renovations and structural improvements.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-md p-8 hover:shadow-xl transition-all duration-300 border border-slate-100"
              >
                <div className="bg-slate-100 w-14 h-14 rounded-lg flex items-center justify-center mb-6 text-deep-blue">
                  <service.icon size={28} />
                </div>
                <h3 className="text-xl font-bold text-charcoal mb-3">{service.title}</h3>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  {service.description}
                </p>
                <Link
                  to={service.link}
                  className="text-deep-blue font-semibold hover:text-charcoal transition-colors flex items-center gap-2"
                >
                  View Service <ArrowRight size={16} />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Area Section */}
      <section className="py-20 bg-charcoal text-warm-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Serving New Jersey & Surrounding Areas</h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto mb-8">
            From North Jersey suburbs to the Jersey Shore, our team is available for residential projects throughout the state. We know the local building codes and architectural styles that make NJ homes unique.
          </p>
          <Link
            to="/service-areas"
            className="inline-block border-2 border-slate-500 text-warm-white px-8 py-3 rounded-lg font-semibold hover:bg-slate-800 hover:border-slate-800 transition-all duration-200"
          >
            Check Our Service Areas
          </Link>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="py-24 bg-deep-blue text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Let's Build Something That Lasts</h2>
          <p className="text-xl text-blue-100 mb-10">
            Ready to discuss your project? Contact us today for a straightforward consultation and a free estimate.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Link
              to="/contact"
              className="bg-white text-deep-blue px-8 py-4 rounded-lg text-lg font-bold hover:bg-slate-100 transition-all duration-200 shadow-lg w-full sm:w-auto"
            >
              Request a Free Estimate
            </Link>
            <div className="flex flex-col items-center sm:items-start">
              <span className="text-sm text-blue-200 uppercase tracking-wider font-semibold">Or Call Us Directly</span>
              <a href="tel:6092097810" className="text-2xl font-bold hover:text-blue-200 transition-colors">
                609-209-7810
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;