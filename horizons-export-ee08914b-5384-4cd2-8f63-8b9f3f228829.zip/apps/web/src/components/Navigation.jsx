import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Projects', path: '/projects' },
    { name: 'Service Areas', path: '/service-areas' },
    { name: 'Contact', path: '/contact' }
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 font-sans ${
      isScrolled ? 'bg-charcoal shadow-lg py-2' : 'bg-charcoal/95 py-4'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 z-50">
            <div className="text-warm-white flex flex-col">
              <span className="text-2xl font-bold leading-none tracking-tight">Linart</span>
              <span className="text-sm font-light text-slate-300 leading-none tracking-widest uppercase">Construction Inc.</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-medium transition-colors duration-200 hover:text-white ${
                  location.pathname === link.path ? 'text-white border-b-2 border-deep-blue pb-1' : 'text-slate-300'
                }`}
              >
                {link.name}
              </Link>
            ))}
            <a
              href="tel:6092097810"
              className="flex items-center gap-2 bg-deep-blue text-white px-5 py-2.5 rounded-md hover:bg-blue-700 transition-all duration-200 font-bold text-sm shadow-md"
            >
              <Phone size={16} />
              <span>609-209-7810</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden text-white hover:text-blue-300 transition-colors duration-200 z-50"
            aria-label="Toggle menu"
          >
            {isOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {/* Mobile Navigation Overlay */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: '100vh' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 top-0 bg-charcoal z-40 flex flex-col pt-24 px-6"
            >
              <div className="flex flex-col space-y-4">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`block py-3 text-xl font-medium border-b border-slate-700 ${
                      location.pathname === link.path ? 'text-white' : 'text-slate-400'
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
                <a
                  href="tel:6092097810"
                  className="flex items-center justify-center gap-2 bg-deep-blue text-white px-6 py-4 rounded-lg hover:bg-opacity-90 transition-all duration-200 shadow-md mt-6 font-bold"
                >
                  <Phone size={20} />
                  <span>Call 609-209-7810</span>
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
};

export default Navigation;