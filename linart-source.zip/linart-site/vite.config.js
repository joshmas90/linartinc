import path from 'node:path';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@': path.resolve(import.meta.dirname, './src') },
  },
  server: {
    // During `npm run dev`, forward form posts to a local PHP server if one is running:
    //   php -S localhost:8000 -t public
    proxy: { '/api': 'http://localhost:8000' },
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
  },
});
