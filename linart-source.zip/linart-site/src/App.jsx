import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { MotionConfig } from 'framer-motion';
import ScrollManager from '@/components/ScrollManager';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import MobileCallBar from '@/components/MobileCallBar';
import HomePage from '@/pages/HomePage';
import AboutPage from '@/pages/AboutPage';
import ServicesPage from '@/pages/ServicesPage';
import ProjectsPage from '@/pages/ProjectsPage';
import ServiceAreasPage from '@/pages/ServiceAreasPage';
import ContactPage from '@/pages/ContactPage';
import NotFoundPage from '@/pages/NotFoundPage';

export default function App() {
  return (
    <HelmetProvider>
      <MotionConfig reducedMotion="user">
        <BrowserRouter>
          <ScrollManager />
          <a href="#main" className="skip-link">Skip to content</a>
          <div className="flex min-h-screen flex-col">
            <Navigation />
            <main id="main" tabIndex={-1} className="flex-1 outline-none">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/services" element={<ServicesPage />} />
                <Route path="/projects" element={<ProjectsPage />} />
                <Route path="/service-areas" element={<ServiceAreasPage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </main>
            <Footer />
            <MobileCallBar />
          </div>
        </BrowserRouter>
      </MotionConfig>
    </HelmetProvider>
  );
}
