export default function PageHeader({ title, intro, children }) {
  return (
    <section className="border-b border-ink/10">
      <div className="wrap pb-14 pt-14 md:pb-20 md:pt-20">
        <h1 className="max-w-4xl text-[clamp(2.4rem,5.5vw,4.25rem)]">{title}</h1>
        {intro && <p className="mt-6 max-w-prose text-lg text-ink/75">{intro}</p>}
        {children}
      </div>
    </section>
  );
}
