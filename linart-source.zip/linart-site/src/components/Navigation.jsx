import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';
import Logo from './Logo';
import { SITE } from '@/config/site';

export const navLinks = [
  { name: 'Services', path: '/services' },
  { name: 'Projects', path: '/projects' },
  { name: 'About', path: '/about' },
  { name: 'Service areas', path: '/service-areas' },
  { name: 'Contact', path: '/contact' },
];

export default function Navigation() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setOpen(false), [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  return (
    <header
      className={`sticky top-0 z-50 border-b bg-paper/95 backdrop-blur transition-colors ${
        scrolled ? 'border-ink/15' : 'border-transparent'
      }`}
    >
      <div className="wrap flex h-[4.5rem] items-center justify-between">
        <Link to="/" aria-label={`${SITE.name}, home`} className="relative z-50">
          <Logo />
        </Link>

        <nav aria-label="Main" className="hidden items-center gap-8 lg:flex">
          {navLinks.map((l) => (
            <NavLink
              key={l.path}
              to={l.path}
              className={({ isActive }) =>
                `text-[0.95rem] font-medium transition-colors ${
                  isActive ? 'text-ink underline decoration-fir decoration-2 underline-offset-[10px]' : 'text-ink/70 hover:text-ink'
                }`
              }
            >
              {l.name}
            </NavLink>
          ))}
          <a href={SITE.phoneHref} className="btn-primary !px-5 !py-2.5 text-[0.95rem]">
            <Phone size={16} aria-hidden="true" />
            {SITE.phoneDisplay}
          </a>
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="relative z-50 -mr-2 p-2 text-ink lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? 'Close menu' : 'Open menu'}
        >
          {open ? <X size={26} /> : <Menu size={26} />}
        </button>
      </div>

      {open && (
        <div id="mobile-menu" className="fixed inset-0 z-40 flex flex-col bg-paper px-5 pb-10 pt-24 lg:hidden">
          <nav aria-label="Mobile" className="flex flex-col">
            <NavLink to="/" end className="border-b border-ink/10 py-4 wide text-2xl font-semibold">Home</NavLink>
            {navLinks.map((l) => (
              <NavLink key={l.path} to={l.path} className={({ isActive }) => `border-b border-ink/10 py-4 wide text-2xl font-semibold ${isActive ? 'text-fir' : 'text-ink'}`}>
                {l.name}
              </NavLink>
            ))}
          </nav>
          <div className="mt-auto grid gap-3">
            <a href={SITE.phoneHref} className="btn-primary w-full text-lg">
              <Phone size={20} aria-hidden="true" /> Call {SITE.phoneDisplay}
            </a>
            <Link to="/contact" className="btn-quiet w-full text-lg">Request an estimate</Link>
          </div>
        </div>
      )}
    </header>
  );
}
