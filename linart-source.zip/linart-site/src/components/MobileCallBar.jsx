import { Link, useLocation } from 'react-router-dom';
import { Phone } from 'lucide-react';
import { SITE } from '@/config/site';

// Always-reachable call and estimate buttons on phones.
export default function MobileCallBar() {
  const { pathname } = useLocation();
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-2 gap-px border-t border-ink/15 bg-ink/15 md:hidden" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
      <a href={SITE.phoneHref} className="flex items-center justify-center gap-2 bg-fir py-4 font-semibold text-white">
        <Phone size={18} aria-hidden="true" /> Call now
      </a>
      {pathname === '/contact' ? (
        <a href={`mailto:${SITE.email}`} className="flex items-center justify-center bg-paper py-4 font-semibold text-ink">Email us</a>
      ) : (
        <Link to="/contact" className="flex items-center justify-center bg-paper py-4 font-semibold text-ink">Free estimate</Link>
      )}
    </div>
  );
}
