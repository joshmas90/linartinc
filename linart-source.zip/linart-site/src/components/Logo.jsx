// Framing square mark: an "L" for Linart, with measurement ticks.
export function Mark({ className = 'h-8 w-8', tick = '#C98D52' }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <path d="M8 3h6v18h15v6H8z" fill="currentColor" />
      <path d="M11 8h3M11 12h3M11 16h3M18 21v3M22 21v3M26 21v3" stroke={tick} strokeWidth="1.5" />
    </svg>
  );
}

export default function Logo({ dark = false }) {
  return (
    <span className="flex items-center gap-2.5">
      <Mark className={`h-9 w-9 ${dark ? 'text-paper' : 'text-ink'}`} />
      <span className="flex flex-col leading-none">
        <span className={`wide text-xl font-bold tracking-tight ${dark ? 'text-paper' : 'text-ink'}`}>Linart</span>
        <span className={`mt-1 text-[0.78rem] ${dark ? 'text-paper/60' : 'text-ink/60'}`}>Construction Inc.</span>
      </span>
    </span>
  );
}
