import { Helmet } from 'react-helmet-async';
import { SITE } from '@/config/site';

export default function Seo({ title, description, path = '/', noindex = false }) {
  const fullTitle = title
    ? `${title} | ${SITE.name}`
    : `${SITE.name} | Home Additions & Remodeling in New Jersey`;
  const url = SITE.url + path;
  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      <link rel="canonical" href={url} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={url} />
      {noindex && <meta name="robots" content="noindex" />}
    </Helmet>
  );
}
