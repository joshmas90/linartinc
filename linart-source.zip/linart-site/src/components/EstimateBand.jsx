import { Link } from 'react-router-dom';
import { SITE } from '@/config/site';

// Closing call to action: the phone number is the headline.
export default function EstimateBand({ heading = 'Talk to us about your project.' }) {
  return (
    <section className="bg-stone text-paper">
      <div className="wrap py-20 md:py-28">
        <h2 className="max-w-2xl text-3xl md:text-4xl">{heading}</h2>
        <p className="mt-4 max-w-prose text-paper/80">
          Estimates are free. Call, or send a few details online and we'll get back to you.
        </p>
        <a
          href={SITE.phoneHref}
          className="wide mt-10 block text-[clamp(2.6rem,9vw,7rem)] font-bold leading-none tracking-tight text-paper transition-colors hover:text-fir-light"
        >
          {SITE.phoneDisplay}
        </a>
        <div className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-3 text-paper/80">
          <Link to="/contact" className="btn-quiet-dark">Request an estimate online</Link>
          <a href={`mailto:${SITE.email}`} className="link">{SITE.email}</a>
        </div>
      </div>
    </section>
  );
}
