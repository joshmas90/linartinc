import { Link } from 'react-router-dom';
import Logo from './Logo';
import { SITE } from '@/config/site';
import { services } from '@/data/services';
import { navLinks } from './Navigation';

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-ink pb-24 pt-16 text-paper/75 md:pb-10">
      <div className="wrap">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-4">
            <Logo dark />
            <p className="mt-5 max-w-xs text-[0.95rem] leading-relaxed">
              Family-owned residential contractor building additions and remodels across New Jersey since {SITE.founded}.
            </p>
          </div>

          <div className="md:col-span-3">
            <h2 className="text-[0.95rem] font-semibold text-paper" style={{ fontStretch: '100%' }}>Services</h2>
            <ul className="mt-4 space-y-2.5 text-[0.95rem]">
              {services.map((s) => (
                <li key={s.slug}><Link to={`/services#${s.slug}`} className="hover:text-paper">{s.title}</Link></li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-2">
            <h2 className="text-[0.95rem] font-semibold text-paper" style={{ fontStretch: '100%' }}>Company</h2>
            <ul className="mt-4 space-y-2.5 text-[0.95rem]">
              {navLinks.filter((l) => l.path !== '/services').map((l) => (
                <li key={l.path}><Link to={l.path} className="hover:text-paper">{l.name}</Link></li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3">
            <h2 className="text-[0.95rem] font-semibold text-paper" style={{ fontStretch: '100%' }}>Contact</h2>
            <ul className="mt-4 space-y-2.5 text-[0.95rem]">
              <li><a href={SITE.phoneHref} className="text-lg font-semibold text-paper hover:text-fir-light">{SITE.phoneDisplay}</a></li>
              <li><a href={`mailto:${SITE.email}`} className="hover:text-paper">{SITE.email}</a></li>
              <li>Serving all of New Jersey</li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-2 border-t border-paper/15 pt-6 text-sm text-paper/55 md:flex-row md:justify-between">
          <p>&copy; {year} {SITE.name} Licensed and insured.</p>
          {SITE.hicNumber && <p>NJ Home Improvement Contractor Reg. #{SITE.hicNumber}</p>}
        </div>
      </div>
    </footer>
  );
}
