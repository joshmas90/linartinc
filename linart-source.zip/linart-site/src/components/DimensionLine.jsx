import { motion } from 'framer-motion';

// Architect's dimension line: start |<—— label ——>| end
export default function DimensionLine({ start, end, label, bg = '#EEF0EC', animate = false, srLabel, className = '' }) {
  return (
    <div className={`dim ${className}`} style={{ '--dim-bg': bg }}>
      {srLabel && <span className="sr-only">{srLabel}</span>}
      {start && <span aria-hidden="true">{start}</span>}
      <span className="dim-track" aria-hidden="true">
        {animate ? (
          <motion.span
            className="dim-line"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 1.1, delay: 0.35, ease: [0.2, 0.7, 0.2, 1] }}
          />
        ) : (
          <span className="dim-line" />
        )}
        {label && (
          <motion.span
            className="dim-label"
            initial={animate ? { opacity: 0 } : false}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4, delay: animate ? 1.2 : 0 }}
          >
            {label}
          </motion.span>
        )}
      </span>
      {end && <span aria-hidden="true">{end}</span>}
    </div>
  );
}
