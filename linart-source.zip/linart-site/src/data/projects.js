// ---------------------------------------------------------------------------
// IMPORTANT: These entries came from the original site and use STOCK photos.
// They are not Linart jobs. Replace each one with a real project (photo in
// /public/images/projects/, real town, real description) before relying on
// this page. Portrait and landscape photos both work; the grid adapts.
// ---------------------------------------------------------------------------
export const projectCategories = ['All', 'Kitchens', 'Bathrooms', 'Additions', 'Basements', 'Whole-home'];

export const projects = [
  { id: 1, title: 'Kitchen remodel', town: 'Princeton', category: 'Kitchens', image: '/images/kitchen-2.webp', description: 'Custom cabinetry and quartz countertops.' },
  { id: 2, title: 'Bathroom renovation', town: 'Newark', category: 'Bathrooms', image: '/images/bathroom-2.webp', description: 'Walk-in shower and heated floors.' },
  { id: 3, title: 'Home addition', town: 'Montclair', category: 'Additions', image: '/images/addition.webp', description: 'Two-story addition with a primary suite and home office.' },
  { id: 4, title: 'Basement finishing', town: 'Jersey City', category: 'Basements', image: '/images/basement.webp', description: 'Entertainment space with a custom bar and theater.' },
  { id: 5, title: 'Contemporary kitchen', town: 'Summit', category: 'Kitchens', image: '/images/kitchen.webp', description: 'Waterfall island and integrated appliances.' },
  { id: 6, title: 'Primary bath', town: 'Hoboken', category: 'Bathrooms', image: '/images/bathroom.webp', description: 'Soaking tub and dual vanities.' },
  { id: 7, title: 'Whole-home renovation', town: 'Westfield', category: 'Whole-home', image: '/images/whole-home.webp', description: 'Complete interior update throughout.' },
];
