export const regions = [
  { name: 'North Jersey', counties: ['Bergen', 'Essex', 'Hudson', 'Morris', 'Passaic', 'Sussex', 'Warren'] },
  { name: 'Central Jersey', counties: ['Hunterdon', 'Mercer', 'Middlesex', 'Monmouth', 'Somerset', 'Union'] },
  { name: 'South Jersey', counties: ['Atlantic', 'Burlington', 'Camden', 'Cape May', 'Cumberland', 'Gloucester', 'Ocean', 'Salem'] },
];
export const countyCount = regions.reduce((n, r) => n + r.counties.length, 0);
