// Service copy is carried over from the original site.
export const services = [
  {
    slug: 'home-additions',
    formType: 'Home addition',
    title: 'Home additions',
    short: 'More room without moving. We handle everything from foundation to finish so the new space matches the house.',
    description:
      'Expand your square footage without leaving the neighborhood. Whether you need a primary suite, a second-story extension, or a larger family room, we manage the entire structural and finishing process.',
    goodFit: 'Growing families who love where they live but have outgrown the house.',
    image: '/images/addition.webp',
  },
  {
    slug: 'kitchen-remodeling',
    formType: 'Kitchen remodel',
    title: 'Kitchen remodeling',
    short: 'Better layout, more storage, and cabinets and fixtures built to handle daily family use.',
    description:
      'We renovate kitchens to improve workflow, storage, and style. Our team handles demolition, plumbing, electrical, cabinet installation, and countertops to create a durable kitchen that works.',
    goodFit: 'Cramped layouts, outdated appliances, and not enough storage.',
    image: '/images/kitchen.webp',
  },
  {
    slug: 'bathroom-remodeling',
    formType: 'Bathroom remodel',
    title: 'Bathroom remodeling',
    short: 'Proper waterproofing, efficient fixtures, and tile work that lasts.',
    description:
      'From hall baths to primary suites, we build watertight, well-finished bathrooms: new vanities, tiled showers, soaking tubs, and modern fixtures.',
    goodFit: 'Older bathrooms with water damage risk, dated finishes, or poor layouts.',
    image: '/images/bathroom.webp',
  },
  {
    slug: 'basement-finishing',
    formType: 'Basement finishing',
    title: 'Basement finishing',
    short: 'Turn unused concrete into real living space: an office, a playroom, a place to watch the game.',
    description:
      'We frame, insulate, and finish basements into warm, usable rooms for home theaters, gyms, offices, or playrooms.',
    goodFit: 'Adding usable square footage without adding onto the house.',
    image: '/images/basement.webp',
  },
  {
    slug: 'whole-home-renovations',
    formType: 'Whole-home renovation',
    title: 'Whole-home renovations',
    short: 'Top-to-bottom updates, managed as one project on one timeline.',
    description:
      'Complete renovations for older homes. We update the major systems (HVAC, electrical, plumbing) while preserving the character you want to keep, or fully modernize the interior layout.',
    goodFit: 'Fixer-upper purchases or bringing an aging family home up to date.',
    image: '/images/whole-home.webp',
  },
  {
    slug: 'structural-remodeling',
    formType: 'Structural work',
    title: 'Structural remodeling',
    short: 'Load-bearing walls removed, beams installed, and layouts opened up safely and to code.',
    description:
      'Removal of load-bearing walls, beam installation, and structural repairs. We protect the integrity of your home while opening up the floor plan.',
    goodFit: 'Opening up older, closed-off floor plans safely and legally.',
    image: '/images/structural.webp',
  },
];
