// Single source of truth for business details used across the site.
// Change a value here and it updates everywhere.
export const SITE = {
  name: 'Linart Construction Inc.',
  shortName: 'Linart',
  url: 'https://linartinc.com',
  phoneDisplay: '609-209-7810',
  phoneHref: 'tel:+16092097810',
  email: 'services@linartinc.com',
  founded: 2004,
  // New Jersey requires home improvement contractors to show their HIC
  // registration number (13VH########) on advertising, including websites.
  // Enter it here and it will appear in the footer automatically.
  hicNumber: '',
};
