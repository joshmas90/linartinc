import { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Phone, Mail, Check } from 'lucide-react';
import Seo from '@/components/Seo';
import { SITE } from '@/config/site';

const PROJECT_TYPES = [
  'Home addition', 'Kitchen remodel', 'Bathroom remodel', 'Basement finishing',
  'Whole-home renovation', 'Structural work', 'Something else',
];

const EMPTY = { name: '', phone: '', email: '', town: '', projectType: '', message: '', company_website: '' };

function validate(v) {
  const e = {};
  if (v.name.trim().length < 2) e.name = 'Enter your name.';
  const digits = v.phone.replace(/\D/g, '');
  if (digits.length < 10 || digits.length > 15) e.phone = 'Enter a phone number with area code.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email.trim())) e.email = 'Enter a valid email address.';
  if (v.message.trim().length < 10) e.message = 'Tell us a little about the project (a sentence or two).';
  return e;
}

export default function ContactPage() {
  const location = useLocation();
  const [values, setValues] = useState(() => ({ ...EMPTY, projectType: location.state?.projectType || '' }));
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle'); // idle | sending | sent | error
  const [serverError, setServerError] = useState('');
  const startedAt = useRef(Date.now());
  const formRef = useRef(null);
  const doneRef = useRef(null);

  useEffect(() => {
    if (status === 'sent') doneRef.current?.focus();
  }, [status]);

  const onChange = (e) => {
    const { name, value } = e.target;
    setValues((v) => ({ ...v, [name]: value }));
    if (errors[name]) setErrors((er) => ({ ...er, [name]: undefined }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length) {
      const first = Object.keys(found)[0];
      formRef.current?.querySelector(`[name="${first}"]`)?.focus();
      return;
    }
    setStatus('sending');
    setServerError('');
    try {
      const res = await fetch('/api/contact.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...values, startedAt: startedAt.current }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        setStatus('sent');
        return;
      }
      if (data.fields) setErrors(data.fields);
      setServerError(data.error || `Something went wrong. Please call us at ${SITE.phoneDisplay}.`);
      setStatus('error');
    } catch {
      setServerError(`We couldn't reach the server. Check your connection, or call us at ${SITE.phoneDisplay}.`);
      setStatus('error');
    }
  };

  const field = (name) => ({
    id: name,
    name,
    value: values[name],
    onChange,
    className: 'field',
    'aria-invalid': errors[name] ? 'true' : undefined,
    'aria-describedby': errors[name] ? `${name}-error` : undefined,
  });

  const Err = ({ name }) =>
    errors[name] ? <p id={`${name}-error`} className="mt-1.5 text-sm font-medium text-red-700">{errors[name]}</p> : null;

  return (
    <>
      <Seo
        title="Contact and free estimates"
        path="/contact"
        description={`Request a free estimate for your New Jersey addition or remodel. Call ${SITE.phoneDisplay} or send us a few details online.`}
      />

      <section className="wrap grid gap-14 py-14 md:py-20 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-5">
          <h1 className="text-[clamp(2.4rem,5.5vw,4.25rem)]">Request a free estimate</h1>
          <p className="mt-6 max-w-prose text-lg text-ink/75">
            Tell us what you have in mind. A few sentences is plenty; we'll ask the right questions when we talk.
          </p>

          <div className="mt-12 space-y-8">
            <div>
              <p className="text-sm text-ink/60">Call</p>
              <a href={SITE.phoneHref} className="wide mt-1 inline-flex items-center gap-3 text-3xl font-bold hover:text-fir md:text-4xl">
                <Phone size={26} aria-hidden="true" className="text-fir" /> {SITE.phoneDisplay}
              </a>
            </div>
            <div>
              <p className="text-sm text-ink/60">Email</p>
              <a href={`mailto:${SITE.email}`} className="mt-1 inline-flex items-center gap-2 text-lg font-semibold hover:text-fir">
                <Mail size={18} aria-hidden="true" className="text-fir" /> {SITE.email}
              </a>
            </div>
          </div>

          <div className="mt-14 border-t border-ink/15 pt-8">
            <h2 className="text-xl" style={{ fontStretch: '112%' }}>What happens next</h2>
            <ol className="mt-5 space-y-4">
              {[
                'We read your request and call you to talk through the project.',
                'We set up a visit to see the space and take measurements.',
                'You get a written estimate. There is no cost or obligation.',
              ].map((t, i) => (
                <li key={i} className="flex gap-4">
                  <span className="wide mt-0.5 text-sm font-semibold text-fir">{i + 1}</span>
                  <span className="text-ink/80">{t}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="bg-white p-6 shadow-[0_1px_0_rgba(30,36,38,.08),0_20px_50px_-30px_rgba(30,36,38,.35)] sm:p-10">
            {status === 'sent' ? (
              <div ref={doneRef} tabIndex={-1} role="status" className="py-10 outline-none">
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-stone text-paper">
                  <Check size={24} aria-hidden="true" />
                </span>
                <h2 className="mt-6 text-3xl">Request received</h2>
                <p className="mt-4 max-w-prose text-lg text-ink/75">
                  Thanks, {values.name.split(' ')[0]}. We'll be in touch at {values.phone}. If it's urgent, call us at{' '}
                  <a href={SITE.phoneHref} className="link font-semibold">{SITE.phoneDisplay}</a>.
                </p>
              </div>
            ) : (
              <form ref={formRef} onSubmit={onSubmit} noValidate className="grid gap-6">
                <div className="grid gap-6 sm:grid-cols-2">
                  <div>
                    <label htmlFor="name" className="mb-2 block font-medium">Name</label>
                    <input type="text" autoComplete="name" {...field('name')} />
                    <Err name="name" />
                  </div>
                  <div>
                    <label htmlFor="phone" className="mb-2 block font-medium">Phone</label>
                    <input type="tel" autoComplete="tel" inputMode="tel" {...field('phone')} />
                    <Err name="phone" />
                  </div>
                </div>
                <div className="grid gap-6 sm:grid-cols-2">
                  <div>
                    <label htmlFor="email" className="mb-2 block font-medium">Email</label>
                    <input type="email" autoComplete="email" {...field('email')} />
                    <Err name="email" />
                  </div>
                  <div>
                    <label htmlFor="town" className="mb-2 block font-medium">
                      Town <span className="font-normal text-ink/55">(optional)</span>
                    </label>
                    <input type="text" autoComplete="address-level2" {...field('town')} />
                  </div>
                </div>
                <div>
                  <label htmlFor="projectType" className="mb-2 block font-medium">
                    Type of project <span className="font-normal text-ink/55">(optional)</span>
                  </label>
                  <select {...field('projectType')}>
                    <option value="">Choose one</option>
                    {PROJECT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label htmlFor="message" className="mb-2 block font-medium">About the project</label>
                  <textarea rows={6} placeholder="For example: we'd like to add a primary suite over the garage." {...field('message')} className="field resize-y" />
                  <Err name="message" />
                </div>

                {/* Spam trap: hidden from people, bots fill it in */}
                <div aria-hidden="true" className="absolute -left-[9999px] h-px w-px overflow-hidden">
                  <label htmlFor="company_website">Leave this empty</label>
                  <input type="text" tabIndex={-1} autoComplete="off" {...field('company_website')} />
                </div>

                {status === 'error' && serverError && (
                  <p role="alert" className="border-l-2 border-red-700 bg-red-50 px-4 py-3 text-red-800">{serverError}</p>
                )}

                <button type="submit" disabled={status === 'sending'} className="btn-primary w-full text-lg disabled:cursor-wait disabled:opacity-70 sm:w-auto sm:justify-self-start">
                  {status === 'sending' ? 'Sending…' : 'Send estimate request'}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </>
  );
}
