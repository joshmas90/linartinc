import Seo from '@/components/Seo';
import DimensionLine from '@/components/DimensionLine';
import EstimateBand from '@/components/EstimateBand';
import { SITE } from '@/config/site';

export default function AboutPage() {
  const year = new Date().getFullYear();
  return (
    <>
      <Seo
        title="About us"
        path="/about"
        description={`Linart Construction Inc. is a family-owned residential contractor serving New Jersey since ${SITE.founded}, with more than 80 years of combined experience.`}
      />

      <section className="wrap grid gap-12 py-14 md:py-20 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <h1 className="text-[clamp(2.4rem,5.5vw,4.25rem)]">A family business, built on reputation.</h1>
          <DimensionLine className="mt-10 max-w-md text-ink/70" start={SITE.founded} end={year} label={`${year - SITE.founded} years`} srLabel={`Founded in ${SITE.founded}.`} />
          <div className="mt-12 max-w-prose space-y-6 text-lg leading-relaxed text-ink/85">
            <p>
              Linart Construction Inc. was founded in {SITE.founded} with a clear goal: to give New Jersey homeowners a reliable, skilled, and honest partner for their renovations. We aren't a corporate franchise. We're a family-owned business that lives and works in the same communities you do.
            </p>
            <p>
              For two decades we've focused only on residential work. Remodeling isn't just lumber and drywall. It's respecting your home, keeping disruption to your daily life to a minimum, and delivering finished work that holds up for years.
            </p>
            <p>
              When you hire Linart, you hire a team that takes personal pride in every nail driven and every tile laid. We don't cut corners, because our family name is on the line.
            </p>
          </div>
        </div>
        <div className="lg:col-span-5">
          <img src="/images/structural.webp" alt="" className="aspect-[4/5] w-full object-cover lg:sticky lg:top-28" />
        </div>
      </section>

      <section className="bg-white">
        <div className="wrap grid gap-10 py-20 md:grid-cols-3 md:py-24">
          {[
            ['Family-owned since ' + SITE.founded, 'Stability and accountability you can count on.'],
            ['Residential only', 'Houses are all we do, so we know how they are built and how they age.'],
            ['Straight communication', 'From the first meeting to the final walkthrough, you know where things stand. No hidden fees.'],
          ].map(([h, t]) => (
            <div key={h} className="border-t-2 border-ink pt-6">
              <h2 className="text-xl" style={{ fontStretch: '112%' }}>{h}</h2>
              <p className="mt-3 text-ink/75">{t}</p>
            </div>
          ))}
        </div>
      </section>

      <EstimateBand />
    </>
  );
}
