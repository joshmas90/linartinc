import { useCallback, useEffect, useRef, useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import Seo from '@/components/Seo';
import PageHeader from '@/components/PageHeader';
import EstimateBand from '@/components/EstimateBand';
import { projects, projectCategories } from '@/data/projects';

export default function ProjectsPage() {
  const [category, setCategory] = useState('All');
  const [openIndex, setOpenIndex] = useState(null);
  const lastTrigger = useRef(null);
  const closeBtn = useRef(null);

  const shown = category === 'All' ? projects : projects.filter((p) => p.category === category);
  const current = openIndex !== null ? shown[openIndex] : null;

  const close = useCallback(() => {
    setOpenIndex(null);
    lastTrigger.current?.focus();
  }, []);
  const step = useCallback((d) => setOpenIndex((i) => (i + d + shown.length) % shown.length), [shown.length]);

  useEffect(() => {
    if (openIndex === null) return;
    closeBtn.current?.focus();
    document.body.style.overflow = 'hidden';
    const onKey = (e) => {
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowRight') step(1);
      if (e.key === 'ArrowLeft') step(-1);
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', onKey);
    };
  }, [openIndex, close, step]);

  return (
    <>
      <Seo
        title="Projects"
        path="/projects"
        description="Kitchens, bathrooms, additions, basements, and whole-home renovations by Linart Construction in New Jersey."
      />
      <PageHeader title="Projects" intro="A look at the kind of work we do across New Jersey.">
        <div role="group" aria-label="Filter projects" className="mt-10 flex flex-wrap gap-2">
          {projectCategories.map((c) => (
            <button
              key={c}
              type="button"
              aria-pressed={category === c}
              onClick={() => setCategory(c)}
              className={`rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
                category === c ? 'border-ink bg-ink text-paper' : 'border-ink/20 text-ink/80 hover:border-ink hover:text-ink'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </PageHeader>

      <section className="wrap py-14 md:py-20">
        <p className="sr-only" aria-live="polite">{shown.length} projects shown</p>
        <ul className="columns-1 gap-6 sm:columns-2 lg:columns-3">
          {shown.map((p, i) => (
            <li key={p.id} className="mb-6 break-inside-avoid">
              <button
                type="button"
                onClick={(e) => { lastTrigger.current = e.currentTarget; setOpenIndex(i); }}
                className="group block w-full text-left"
              >
                <span className="block overflow-hidden bg-ink/5">
                  <img src={p.image} alt="" loading="lazy" className="w-full transition-transform duration-700 group-hover:scale-[1.03]" />
                </span>
                <span className="mt-3 flex items-baseline justify-between gap-4">
                  <span className="semiwide font-semibold group-hover:text-fir">{p.title}</span>
                  <span className="shrink-0 text-sm text-ink/60">{p.town}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      </section>

      {current && (
        <div role="dialog" aria-modal="true" aria-label={`${current.title}, ${current.town}`} className="fixed inset-0 z-[60] flex flex-col bg-ink/95 text-paper" onClick={close}>
          <div className="wrap flex items-center justify-between py-4" onClick={(e) => e.stopPropagation()}>
            <p className="text-sm text-paper/70">{openIndex + 1} of {shown.length}</p>
            <button ref={closeBtn} type="button" onClick={close} aria-label="Close" className="-mr-2 p-2 hover:text-fir-light">
              <X size={28} />
            </button>
          </div>
          <div className="relative flex min-h-0 flex-1 items-center justify-center px-4 sm:px-16">
            <img src={current.image} alt={current.description} className="max-h-full max-w-full object-contain" onClick={(e) => e.stopPropagation()} />
            {shown.length > 1 && (
              <>
                <button type="button" onClick={(e) => { e.stopPropagation(); step(-1); }} aria-label="Previous project" className="absolute left-1 top-1/2 -translate-y-1/2 p-3 hover:text-fir-light sm:left-4">
                  <ChevronLeft size={34} />
                </button>
                <button type="button" onClick={(e) => { e.stopPropagation(); step(1); }} aria-label="Next project" className="absolute right-1 top-1/2 -translate-y-1/2 p-3 hover:text-fir-light sm:right-4">
                  <ChevronRight size={34} />
                </button>
              </>
            )}
          </div>
          <div className="wrap py-6 text-center" onClick={(e) => e.stopPropagation()}>
            <h2 className="text-xl" style={{ fontStretch: '112%' }}>{current.title}, {current.town}</h2>
            <p className="mt-1 text-paper/70">{current.description}</p>
          </div>
        </div>
      )}

      <EstimateBand />
    </>
  );
}
