import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Phone } from 'lucide-react';
import Seo from '@/components/Seo';
import DimensionLine from '@/components/DimensionLine';
import EstimateBand from '@/components/EstimateBand';
import { SITE } from '@/config/site';
import { services } from '@/data/services';
import { countyCount } from '@/data/areas';

const steps = [
  { title: 'Consultation', text: 'We visit the house, listen to what you want, and look at what the structure allows.' },
  { title: 'Estimate', text: 'You get a clear written estimate with the scope spelled out.' },
  { title: 'Permits', text: 'We handle the township permits and inspections.' },
  { title: 'Build', text: 'Our crew does the work and keeps you informed as it moves.' },
  { title: 'Walkthrough', text: 'We walk the finished space with you before we call it done.' },
];

export default function HomePage() {
  const year = new Date().getFullYear();
  const years = year - SITE.founded;
  const [active, setActive] = useState(0);

  return (
    <>
      <Seo
        description={`Family-owned since ${SITE.founded}. Linart Construction builds home additions and remodels kitchens, bathrooms, and basements across New Jersey. Call ${SITE.phoneDisplay} for a free estimate.`}
      />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-ink/10">
        <div className="grid lg:min-h-[calc(100svh-4.5rem)] lg:grid-cols-12">
          <div className="order-2 flex flex-col justify-center px-5 py-14 sm:px-8 lg:order-1 lg:col-span-7 lg:py-20 lg:pl-[max(2rem,calc((100vw-80rem)/2+2rem))] lg:pr-16">
            <motion.h1
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.2, 0.7, 0.2, 1] }}
              className="max-w-[15ch] text-[clamp(2.5rem,4.6vw,4.4rem)] leading-[1.02]"
            >
              Additions and remodels for New Jersey homes.
            </motion.h1>
            <p className="mt-7 max-w-[34rem] text-lg text-ink/75">
              A family-owned contractor with more than 80 years of combined experience. We build additions, kitchens, bathrooms, and basements, including structural work like removing load-bearing walls.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link to="/contact" className="btn-primary text-lg">Request a free estimate</Link>
              <a href={SITE.phoneHref} className="btn-quiet text-lg">
                <Phone size={18} aria-hidden="true" /> {SITE.phoneDisplay}
              </a>
            </div>

            <DimensionLine
              className="mt-14 max-w-[34rem] text-ink/70"
              start={`Est. ${SITE.founded}`}
              end={year}
              label={`${years} years`}
              srLabel={`Established ${SITE.founded}, ${years} years in business.`}
              animate
            />
          </div>

          <div className="relative order-1 h-[42vh] min-h-[16rem] lg:order-2 lg:col-span-5 lg:h-auto">
            <img
              src="/images/hero.webp"
              alt="A New Jersey home"
              className="absolute inset-0 h-full w-full object-cover"
              width="1600"
              height="900"
              fetchpriority="high"
            />
          </div>
        </div>
      </section>

      {/* Facts */}
      <section aria-label="At a glance" className="border-b border-ink/10 bg-white">
        <div className="wrap">
          <dl className="grid grid-cols-2 gap-px bg-ink/10 md:grid-cols-4">
            {[
              ['Since', String(SITE.founded)],
              ['Combined experience', '80+ years'],
              ['Counties served', String(countyCount)],
              ['Ownership', 'Family'],
            ].map(([label, value]) => (
              <div key={label} className="bg-white px-5 py-8 md:px-8 md:py-10">
                <dt className="text-sm text-ink/60">{label}</dt>
                <dd className="wide mt-1 text-[1.35rem] font-bold sm:text-2xl md:text-3xl">{value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* Services index */}
      <section className="wrap py-20 md:py-28">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <h2 className="text-3xl md:text-[2.75rem]">What we build</h2>
            <p className="mt-4 max-w-prose text-ink/75">
              Major residential work, managed from foundation to finish.
            </p>
            <ul className="mt-10 border-t border-ink/15">
              {services.map((s, i) => (
                <li key={s.slug} className="border-b border-ink/15">
                  <Link
                    to={`/services#${s.slug}`}
                    onMouseEnter={() => setActive(i)}
                    onFocus={() => setActive(i)}
                    className="group grid gap-2 py-6 md:grid-cols-[1fr_1.3fr] md:gap-8"
                  >
                    <span className={`semiwide text-xl font-semibold transition-colors md:text-2xl ${active === i ? 'text-fir' : 'text-ink'} group-hover:text-fir`}>
                      {s.title}
                    </span>
                    <span className="text-ink/70">{s.short}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div className="hidden lg:col-span-5 lg:block">
            <div className="sticky top-28 aspect-[4/5] overflow-hidden bg-ink/5">
              {services.map((s, i) => (
                <img
                  key={s.slug}
                  src={s.image}
                  alt=""
                  loading="lazy"
                  className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-500 ${active === i ? 'opacity-100' : 'opacity-0'}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="bg-ink text-paper">
        <div className="wrap py-20 md:py-28">
          <h2 className="max-w-2xl text-3xl md:text-[2.75rem]">How a project runs</h2>
          <p className="mt-4 max-w-prose text-paper/70">
            No surprises. You'll know what happens next at every stage.
          </p>
          <ol className="mt-14 grid gap-10 md:grid-cols-5 md:gap-0">
            {steps.map((s, i) => (
              <li key={s.title} className="relative md:pr-6">
                <div className="mb-5 hidden h-[14px] md:block" aria-hidden="true">
                  <span className="absolute left-0 top-0 h-[14px] w-px bg-paper/50" />
                  <span className="absolute left-0 right-0 top-[7px] h-px bg-paper/30" />
                  {i === steps.length - 1 && <span className="absolute right-0 top-0 h-[14px] w-px bg-paper/50" />}
                </div>
                <span className="wide text-sm font-semibold text-fir-light">{String(i + 1).padStart(2, '0')}</span>
                <h3 className="mt-2 text-xl" style={{ fontStretch: '112%' }}>{s.title}</h3>
                <p className="mt-2 text-[0.95rem] text-paper/70">{s.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Area */}
      <section className="wrap grid gap-8 py-20 md:grid-cols-12 md:py-24">
        <h2 className="text-3xl md:col-span-5 md:text-[2.75rem]">All {countyCount} New Jersey counties</h2>
        <div className="md:col-span-6 md:col-start-7">
          <p className="text-lg text-ink/75">
            From Bergen County to Cape May, we work throughout the state. We know the local building codes, the township permit offices, and the architectural styles that make New Jersey homes what they are.
          </p>
          <Link to="/service-areas" className="link mt-6 inline-block font-semibold">See the service area</Link>
        </div>
      </section>

      <EstimateBand />
    </>
  );
}
