import { Link } from 'react-router-dom';
import Seo from '@/components/Seo';
import DimensionLine from '@/components/DimensionLine';

export default function NotFoundPage() {
  return (
    <>
      <Seo title="Page not found" description="This page doesn't exist." noindex />
      <section className="wrap py-24 md:py-36">
        <h1 className="text-[clamp(2.4rem,5.5vw,4.25rem)]">This page doesn't exist.</h1>
        <p className="mt-6 max-w-prose text-lg text-ink/75">The link may be old or mistyped. Try one of these instead.</p>
        <DimensionLine className="mt-10 max-w-md text-ink/40" />
        <div className="mt-10 flex flex-wrap gap-3">
          <Link to="/" className="btn-primary">Go to the home page</Link>
          <Link to="/services" className="btn-quiet">See our services</Link>
          <Link to="/contact" className="btn-quiet">Contact us</Link>
        </div>
      </section>
    </>
  );
}
