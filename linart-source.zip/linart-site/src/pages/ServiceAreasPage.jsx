import { Link } from 'react-router-dom';
import Seo from '@/components/Seo';
import PageHeader from '@/components/PageHeader';
import EstimateBand from '@/components/EstimateBand';
import { regions, countyCount } from '@/data/areas';

export default function ServiceAreasPage() {
  return (
    <>
      <Seo
        title="Service areas"
        path="/service-areas"
        description={`Linart Construction serves all ${countyCount} New Jersey counties, from North Jersey to South Jersey, plus parts of Pennsylvania and New York.`}
      />
      <PageHeader
        title="Where we work"
        intro={`All ${countyCount} New Jersey counties, plus parts of Pennsylvania and New York. We know the local building codes, the permit process in each township, and the housing styles of each region.`}
      />

      <section className="wrap py-16 md:py-24">
        <div className="grid gap-12 md:grid-cols-3 md:gap-10">
          {regions.map((r) => (
            <div key={r.name}>
              <h2 className="border-b-2 border-ink pb-4 text-2xl" style={{ fontStretch: '112%' }}>{r.name}</h2>
              <ul className="mt-2">
                {r.counties.map((c) => (
                  <li key={c} className="flex items-baseline justify-between border-b border-ink/10 py-3">
                    <span className="font-medium">{c}</span>
                    <span className="text-sm text-ink/55">County</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-20 grid gap-8 border-t border-ink/15 pt-12 md:grid-cols-12">
          <h2 className="text-2xl md:col-span-5 md:text-3xl">Outside New Jersey?</h2>
          <div className="md:col-span-6 md:col-start-7">
            <p className="text-lg text-ink/75">
              We take on projects in parts of Pennsylvania and New York. Tell us where the house is and we'll let you know if we can help.
            </p>
            <Link to="/contact" className="link mt-6 inline-block font-semibold">Ask about your location</Link>
          </div>
        </div>
      </section>

      <EstimateBand />
    </>
  );
}
