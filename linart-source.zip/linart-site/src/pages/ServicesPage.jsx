import { Link } from 'react-router-dom';
import Seo from '@/components/Seo';
import PageHeader from '@/components/PageHeader';
import EstimateBand from '@/components/EstimateBand';
import { services } from '@/data/services';

export default function ServicesPage() {
  return (
    <>
      <Seo
        title="Services"
        path="/services"
        description="Home additions, kitchen and bathroom remodeling, basement finishing, whole-home renovations, and structural remodeling across New Jersey."
      />
      <PageHeader
        title="Services"
        intro="Six kinds of work, all residential, each managed from the first measurement to the final walkthrough."
      >
        <nav aria-label="Jump to a service" className="mt-10 flex flex-wrap gap-2">
          {services.map((s) => (
            <a key={s.slug} href={`#${s.slug}`} className="rounded-full border border-ink/20 px-4 py-2 text-sm font-medium text-ink/80 transition-colors hover:border-ink hover:text-ink">
              {s.title}
            </a>
          ))}
        </nav>
      </PageHeader>

      <div className="wrap">
        {services.map((s, i) => (
          <section
            key={s.slug}
            id={s.slug}
            aria-labelledby={`${s.slug}-title`}
            className="grid scroll-mt-24 gap-8 border-b border-ink/10 py-16 last:border-0 md:grid-cols-12 md:gap-12 md:py-24"
          >
            <div className={`md:col-span-6 ${i % 2 ? 'md:order-2' : ''}`}>
              <img src={s.image} alt="" loading="lazy" className="aspect-[4/3] w-full object-cover" />
            </div>
            <div className={`flex flex-col justify-center md:col-span-6 ${i % 2 ? 'md:order-1 md:pr-6' : 'md:pl-6'}`}>
              <h2 id={`${s.slug}-title`} className="text-3xl md:text-4xl">{s.title}</h2>
              <p className="mt-5 max-w-prose text-lg text-ink/80">{s.description}</p>
              <p className="mt-6 max-w-prose border-l-2 border-fir pl-4 text-ink/75">
                <span className="font-semibold text-ink">A good fit for: </span>
                {s.goodFit.charAt(0).toLowerCase() + s.goodFit.slice(1)}
              </p>
              <Link to="/contact" state={{ projectType: s.formType }} className="link mt-8 self-start font-semibold text-fir">
                Get an estimate for {s.title.toLowerCase()}
              </Link>
            </div>
          </section>
        ))}
      </div>

      <EstimateBand heading="Not sure which of these fits? Describe the project and we'll tell you." />
    </>
  );
}
