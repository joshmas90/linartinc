<?php
/**
 * Linart Construction – estimate request handler
 * Receives the contact form (JSON POST), validates it, filters spam,
 * saves a backup copy of the lead, and emails it to the office.
 *
 * Requires PHP 8.0+ (Hostinger default is newer).
 */
declare(strict_types=1);

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
const TO_EMAIL        = 'services@linartinc.com';
const FROM_EMAIL      = 'services@linartinc.com'; // must be a mailbox on linartinc.com
const FROM_NAME       = 'Linart Website';
const ALLOWED_HOSTS   = ['linartinc.com', 'www.linartinc.com', 'localhost', '127.0.0.1'];
const RATE_LIMIT      = 5;     // max submissions per IP ...
const RATE_WINDOW     = 3600;  // ... per this many seconds
const MIN_FILL_SECONDS = 3;    // humans take longer than this to fill the form
const PROJECT_TYPES   = [
    'Home addition', 'Kitchen remodel', 'Bathroom remodel', 'Basement finishing',
    'Whole-home renovation', 'Structural work', 'Something else',
];

// ---------------------------------------------------------------------------
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

function respond(int $status, array $body): void
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Private folder one level above public_html, so leads are never web-accessible. */
function private_dir(): string
{
    $dir = dirname(__DIR__, 2) . '/linart-private';
    if (!is_dir($dir) && !@mkdir($dir, 0700, true)) {
        $dir = sys_get_temp_dir() . '/linart-private';
        @mkdir($dir, 0700, true);
    }
    return $dir;
}

function single_line(string $value, int $max): string
{
    $value = preg_replace('/[\r\n\t\0]+/', ' ', $value) ?? '';
    return mb_substr(trim($value), 0, $max);
}

// --- Method & origin -------------------------------------------------------
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    respond(405, ['ok' => false, 'error' => 'Method not allowed.']);
}

$origin = $_SERVER['HTTP_ORIGIN'] ?? $_SERVER['HTTP_REFERER'] ?? '';
if ($origin !== '') {
    $host = parse_url($origin, PHP_URL_HOST) ?: '';
    if (!in_array(strtolower($host), ALLOWED_HOSTS, true)) {
        respond(403, ['ok' => false, 'error' => 'Request not allowed.']);
    }
}

// --- Parse input (JSON or classic form post) --------------------------------
$raw = file_get_contents('php://input', false, null, 0, 20000) ?: '';
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}
$get = static fn(string $k): string => is_string($input[$k] ?? null) ? $input[$k] : '';

// --- Silent spam traps: pretend success so bots learn nothing ----------------
$startedAt = (int) ($input['startedAt'] ?? 0);
$elapsed   = $startedAt > 0 ? (time() * 1000 - $startedAt) / 1000 : 0;
if ($get('company_website') !== '' || $elapsed < MIN_FILL_SECONDS || $elapsed > 172800) {
    respond(200, ['ok' => true]);
}

// --- Rate limit per IP -------------------------------------------------------
$ip      = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$ip      = trim(explode(',', $ip)[0]);
$rlFile  = private_dir() . '/rate-' . hash('sha256', $ip) . '.json';
$now     = time();
$fh      = @fopen($rlFile, 'c+');
if ($fh && flock($fh, LOCK_EX)) {
    $hits = json_decode(stream_get_contents($fh) ?: '[]', true) ?: [];
    $hits = array_values(array_filter($hits, static fn($t) => $t > $now - RATE_WINDOW));
    if (count($hits) >= RATE_LIMIT) {
        flock($fh, LOCK_UN);
        fclose($fh);
        respond(429, ['ok' => false, 'error' => 'Too many requests. Please call us at 609-209-7810.']);
    }
    $hits[] = $now;
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($hits));
    flock($fh, LOCK_UN);
    fclose($fh);
}

// --- Validate ----------------------------------------------------------------
$name        = single_line($get('name'), 100);
$phone       = single_line($get('phone'), 30);
$email       = single_line($get('email'), 254);
$town        = single_line($get('town'), 100);
$projectType = single_line($get('projectType'), 60);
$message     = mb_substr(trim(str_replace("\0", '', $get('message'))), 0, 5000);

$errors = [];
if (mb_strlen($name) < 2) {
    $errors['name'] = 'Enter your name.';
}
$digits = preg_replace('/\D+/', '', $phone) ?? '';
if (strlen($digits) < 10 || strlen($digits) > 15) {
    $errors['phone'] = 'Enter a phone number with area code.';
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Enter a valid email address.';
}
if ($projectType !== '' && !in_array($projectType, PROJECT_TYPES, true)) {
    $projectType = 'Something else';
}
if (mb_strlen($message) < 10) {
    $errors['message'] = 'Tell us a little about the project (a sentence or two).';
}
if ($errors) {
    respond(422, ['ok' => false, 'error' => 'Please check the highlighted fields.', 'fields' => $errors]);
}

// Link-stuffed messages are almost always spam
if (preg_match_all('~https?://|www\.~i', $message) > 3) {
    respond(200, ['ok' => true]);
}

// --- Save a backup copy (leads.csv, outside public_html) -----------------------
$saved = false;
$csv   = private_dir() . '/leads.csv';
$isNew = !file_exists($csv);
if ($out = @fopen($csv, 'a')) {
    if (flock($out, LOCK_EX)) {
        if ($isNew) {
            fputcsv($out, ['Received', 'Name', 'Phone', 'Email', 'Town', 'Project type', 'Message', 'Email sent']);
        }
        $row = [date('Y-m-d H:i:s'), $name, $phone, $email, $town, $projectType, $message];
        $saved = true;
    }
}

// --- Send the email ------------------------------------------------------------
$subject = 'New estimate request: ' . $name . ($projectType !== '' ? " ({$projectType})" : '');
$body = implode("\n", [
    'New estimate request from linartinc.com',
    str_repeat('-', 44),
    "Name:          {$name}",
    "Phone:         {$phone}",
    "Email:         {$email}",
    'Town:          ' . ($town !== '' ? $town : '(not given)'),
    'Project type:  ' . ($projectType !== '' ? $projectType : '(not given)'),
    '',
    'Project description:',
    $message,
    '',
    str_repeat('-', 44),
    'Reply to this email to respond directly to ' . $name . '.',
    'Received ' . date('l, F j, Y \a\t g:i A T'),
]);

$headers = [
    'From: ' . mb_encode_mimeheader(FROM_NAME) . ' <' . FROM_EMAIL . '>',
    'Reply-To: ' . mb_encode_mimeheader($name) . ' <' . $email . '>',
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: 8bit',
];

$sent = @mail(
    TO_EMAIL,
    mb_encode_mimeheader($subject, 'UTF-8'),
    $body,
    implode("\r\n", $headers),
    '-f' . FROM_EMAIL
);

if ($saved) {
    $row[] = $sent ? 'yes' : 'NO';
    fputcsv($out, $row);
    flock($out, LOCK_UN);
    fclose($out);
}

if (!$sent && !$saved) {
    respond(500, ['ok' => false, 'error' => 'We could not send your request. Please call us at 609-209-7810.']);
}

respond(200, ['ok' => true]);
