/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#1E2426',
        paper: '#EEF0EC',
        stone: { DEFAULT: '#3E5561', dark: '#2C3E47', light: '#A9B8BF' },
        fir: { DEFAULT: '#9A5F28', dark: '#7D4B1D', light: '#C98D52' },
      },
      fontFamily: {
        sans: ['Archivo', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      maxWidth: { prose: '38rem' },
    },
  },
  plugins: [],
};
