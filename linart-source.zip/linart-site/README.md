# Linart Construction website

React + Vite site with a PHP form handler, built for Hostinger's
"Custom PHP/HTML website" hosting.

## Editing
- Business details (phone, email, NJ HIC number): `src/config/site.js`
- Services copy: `src/data/services.js`
- Projects gallery: `src/data/projects.js` (currently STOCK PHOTOS; replace with real jobs)
- Counties: `src/data/areas.js`
- Images: `public/images/` (use .webp or .jpg, about 1600px on the long side)

## Build
    npm install
    npm run build        # output goes to dist/

## Deploy to Hostinger
1. hPanel > Emails: make sure services@linartinc.com exists.
2. hPanel > Websites > Add website > Custom PHP/HTML website, domain linartinc.com
   (after removing it from the AI Builder / Horizons site).
3. File Manager > public_html: delete the default files, then upload EVERYTHING
   inside dist/ (including the hidden .htaccess and the api/ folder).
4. hPanel > Security > SSL: make sure SSL is active, and turn on Force HTTPS.
5. Test: submit the contact form, confirm the email arrives at services@linartinc.com
   (check spam the first time and mark it "not spam").

## Automatic deploys from GitHub
Pushing to `main` builds the site and uploads `dist/` to Hostinger over FTP
(see `.github/workflows/deploy.yml`). One-time setup in the GitHub repo under
Settings > Secrets and variables > Actions:
- Secrets: `FTP_SERVER`, `FTP_USERNAME`, `FTP_PASSWORD` (hPanel > Files > FTP Accounts)
- Variable: `FTP_SERVER_DIR`, the path to this site's public_html as seen by that
  FTP account, ending in `/` (often `domains/linartinc.com/public_html/`, or just
  `public_html/`; check where the FTP account lands in File Manager).
Run it by hand anytime from the Actions tab > Deploy to Hostinger > Run workflow.
If the upload step fails with a TLS error, change `protocol: ftps` to `ftp`.

## Leads backup
Every form submission is also saved to `linart-private/leads.csv`, one folder
ABOVE public_html (not reachable from the web). Open it in Excel. The last column
shows whether the email went out, so nothing is lost if mail ever fails.

## Local testing
    npm run build
    php -S localhost:8000 -t dist     # then open http://localhost:8000
